<?php
// navbar.php
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">
            <?php echo isset($_SESSION['tipo']) ? 
                  ($_SESSION['tipo'] == 'admin' ? 'Admin - ' : '') . 'Sistema de Citas Médicas' : 
                  'Sistema de Citas Médicas'; ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <?php if (isset($_SESSION['usuario_id'])): ?>
                    <?php if ($_SESSION['tipo'] == 'paciente'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="mis_citas.php">Mis Citas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="agendar_cita.php">Agendar Cita</a>
                        </li>
                    <?php elseif ($_SESSION['tipo'] == 'doctor'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="mis_citas.php">Mis Citas</a>
                        </li>
                    <?php elseif ($_SESSION['tipo'] == 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="admin_panel.php">Panel de Administración</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="gestion_usuarios.php">Gestionar Usuarios</a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <?php if (isset($_SESSION['usuario_id'])): ?>
                    <li class="nav-item">
                        <span class="navbar-text me-3">Hola, <?php echo htmlspecialchars($_SESSION['nombre']); ?></span>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Cerrar Sesión</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Iniciar Sesión</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="registro.php">Registrarse</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>