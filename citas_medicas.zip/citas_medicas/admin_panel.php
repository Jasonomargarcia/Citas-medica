<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] != 'admin') {
    header("Location: index.php");
    exit;
}

// Obtener estadísticas
$total_pacientes = $conexion->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'paciente'")->fetch_assoc()['total'];
$total_doctores = $conexion->query("SELECT COUNT(*) as total FROM usuarios WHERE tipo = 'doctor'")->fetch_assoc()['total'];
$total_citas = $conexion->query("SELECT COUNT(*) as total FROM citas")->fetch_assoc()['total'];
$citas_hoy = $conexion->query("SELECT COUNT(*) as total FROM citas WHERE fecha = CURDATE()")->fetch_assoc()['total'];

// Últimas citas
$ultimas_citas = $conexion->query("
    SELECT c.id, c.fecha, c.hora, c.estado, 
           p.nombre as paciente, d.nombre as doctor
    FROM citas c
    JOIN usuarios p ON c.paciente_id = p.id
    JOIN usuarios d ON c.doctor_id = d.id
    ORDER BY c.fecha DESC, c.hora DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Sistema de Citas Médicas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .stat-card {
            text-align: center;
            padding: 20px;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
        }
        .stat-label {
            font-size: 1rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid mt-5">
        <h2 class="mb-4">Panel de Administración</h2>
        
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="card stat-card bg-light">
                    <div class="stat-number text-primary"><?php echo $total_pacientes; ?></div>
                    <div class="stat-label">Pacientes Registrados</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-light">
                    <div class="stat-number text-success"><?php echo $total_doctores; ?></div>
                    <div class="stat-label">Doctores Registrados</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-light">
                    <div class="stat-number text-info"><?php echo $total_citas; ?></div>
                    <div class="stat-label">Citas Totales</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-light">
                    <div class="stat-number text-warning"><?php echo $citas_hoy; ?></div>
                    <div class="stat-label">Citas Hoy</div>
                </div>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Últimas Citas</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($ultimas_citas->num_rows > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Fecha</th>
                                            <th>Hora</th>
                                            <th>Paciente</th>
                                            <th>Doctor</th>
                                            <th>Estado</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($cita = $ultimas_citas->fetch_assoc()): ?>
                                            <tr>
                                                <td><?php echo date('d/m/Y', strtotime($cita['fecha'])); ?></td>
                                                <td><?php echo date('H:i', strtotime($cita['hora'])); ?></td>
                                                <td><?php echo $cita['paciente']; ?></td>
                                                <td><?php echo $cita['doctor']; ?></td>
                                                <td>
                                                    <span class="badge badge-<?php echo strtolower($cita['estado']); ?>">
                                                        <?php echo ucfirst($cita['estado']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info">No hay citas registradas.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">Acciones Rápidas</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="gestion_usuarios.php" class="btn btn-outline-primary btn-block">Gestionar Usuarios</a>
                            <a href="gestion_citas.php" class="btn btn-outline-primary btn-block">Gestionar Citas</a>
                            <a href="reportes.php" class="btn btn-outline-primary btn-block">Generar Reportes</a>
                            <a href="configuracion.php" class="btn btn-outline-secondary btn-block">Configuración del Sistema</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>