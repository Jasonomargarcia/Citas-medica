<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$tipo_usuario = $_SESSION['tipo'];

if ($tipo_usuario == 'paciente') {
    $query = "SELECT c.id, c.fecha, c.hora, c.motivo, c.estado, u.nombre as doctor_nombre 
              FROM citas c 
              JOIN usuarios u ON c.doctor_id = u.id 
              WHERE c.paciente_id = ? 
              ORDER BY c.fecha DESC, c.hora DESC";
    $titulo = "Mis Citas Médicas";
} elseif ($tipo_usuario == 'doctor') {
    $query = "SELECT c.id, c.fecha, c.hora, c.motivo, c.estado, u.nombre as paciente_nombre 
              FROM citas c 
              JOIN usuarios u ON c.paciente_id = u.id 
              WHERE c.doctor_id = ? 
              ORDER BY c.fecha DESC, c.hora DESC";
    $titulo = "Citas con Pacientes";
} else {
    header("Location: admin_panel.php");
    exit;
}

$stmt = $conexion->prepare($query);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo; ?> - Sistema de Citas Médicas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .badge-pendiente {
            background-color: #ffc107;
            color: #000;
        }
        .badge-completada {
            background-color: #28a745;
        }
        .badge-cancelada {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><?php echo $titulo; ?></h2>
            <?php if ($tipo_usuario == 'paciente'): ?>
                <a href="agendar_cita.php" class="btn btn-primary">Agendar Nueva Cita</a>
            <?php endif; ?>
        </div>
        
        <?php if ($result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Fecha</th>
                            <th>Hora</th>
                            <th><?php echo $tipo_usuario == 'paciente' ? 'Doctor' : 'Paciente'; ?></th>
                            <th>Motivo</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($cita = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('d/m/Y', strtotime($cita['fecha'])); ?></td>
                                <td><?php echo date('H:i', strtotime($cita['hora'])); ?></td>
                                <td><?php echo $tipo_usuario == 'paciente' ? $cita['doctor_nombre'] : $cita['paciente_nombre']; ?></td>
                                <td><?php echo $cita['motivo']; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo strtolower($cita['estado']); ?>">
                                        <?php echo ucfirst($cita['estado']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($tipo_usuario == 'doctor' && $cita['estado'] == 'pendiente'): ?>
                                        <a href="procesar_cita.php?accion=completar&id=<?php echo $cita['id']; ?>" class="btn btn-sm btn-success">Completar</a>
                                        <a href="procesar_cita.php?accion=cancelar&id=<?php echo $cita['id']; ?>" class="btn btn-sm btn-danger">Cancelar</a>
                                    <?php elseif ($tipo_usuario == 'paciente' && $cita['estado'] == 'pendiente'): ?>
                                        <a href="procesar_cita.php?accion=cancelar&id=<?php echo $cita['id']; ?>" class="btn btn-sm btn-danger">Cancelar</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">No tienes citas registradas.</div>
        <?php endif; ?>
    </div>
</body>
</html>