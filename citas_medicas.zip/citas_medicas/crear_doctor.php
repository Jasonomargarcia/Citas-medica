<?php
require 'conexion.php';

$doctores = [
    ['Dr. López', 'dr.lopez@clinica.com', 'pediatria123'],
    ['Dra. Martínez', 'dra.martinez@clinica.com', 'cardiologia456']
];

foreach ($doctores as $doctor) {
    $hash = password_hash($doctor[2], PASSWORD_DEFAULT);
    $stmt = $conexion->prepare("INSERT INTO usuarios (nombre, email, password, tipo) VALUES (?, ?, ?, 'doctor')");
    $stmt->bind_param("sss", $doctor[0], $doctor[1], $hash);
    
    if ($stmt->execute()) {
        echo "Doctor {$doctor[0]} agregado exitosamente!<br>";
    } else {
        echo "Error al agregar {$doctor[0]}: " . $conexion->error . "<br>";
    }
}

echo "<a href='index.php'>Volver al sistema</a>";
?>