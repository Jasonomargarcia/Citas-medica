<?php
$host = "localhost";
$usuario = "root";
$contraseña = "";
$bd = "citas_medicas";

$conexion = new mysqli($host, $usuario, $contraseña, $bd);

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

// Crear tablas si no existen
$sql = "CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    tipo ENUM('paciente','doctor','admin') NOT NULL
)";

$conexion->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS citas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    paciente_id INT NOT NULL,
    doctor_id INT NOT NULL,
    fecha DATE NOT NULL,
    hora TIME NOT NULL,
    motivo TEXT NOT NULL,
    estado ENUM('pendiente','completada','cancelada') DEFAULT 'pendiente',
    FOREIGN KEY (paciente_id) REFERENCES usuarios(id),
    FOREIGN KEY (doctor_id) REFERENCES usuarios(id)
)";

$conexion->query($sql);
?>