<?php
session_start();
require 'conexion.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit;
}

if ($_SESSION['tipo'] != 'paciente') {
    header("Location: " . ($_SESSION['tipo'] == 'admin' ? 'admin_panel.php' : 'mis_citas.php'));
    exit;
}

// Obtener lista de doctores
$doctores = $conexion->query("SELECT id, nombre FROM usuarios WHERE tipo = 'doctor'");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $doctor_id = $_POST['doctor_id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $motivo = $_POST['motivo'];
    $paciente_id = $_SESSION['usuario_id'];

    // Verificar disponibilidad
    $stmt = $conexion->prepare("SELECT id FROM citas WHERE doctor_id = ? AND fecha = ? AND hora = ?");
    $stmt->bind_param("iss", $doctor_id, $fecha, $hora);
    $stmt->execute();
    
    if ($stmt->get_result()->num_rows > 0) {
        $error = "El doctor ya tiene una cita programada para esa fecha y hora";
    } else {
        $stmt = $conexion->prepare("INSERT INTO citas (paciente_id, doctor_id, fecha, hora, motivo) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisss", $paciente_id, $doctor_id, $fecha, $hora, $motivo);
        
        if ($stmt->execute()) {
            $success = "Cita agendada exitosamente";
        } else {
            $error = "Error al agendar la cita";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar Cita - Sistema de Citas Médicas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Agendar Nueva Cita Médica</h4>
                    </div>
                    <div class="card-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if (isset($success)): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST">
                            <div class="mb-3">
                                <label for="doctor_id" class="form-label">Seleccione Doctor</label>
                                <select class="form-select" id="doctor_id" name="doctor_id" required>
                                    <option value="">-- Seleccione un doctor --</option>
                                    <?php while ($doctor = $doctores->fetch_assoc()): ?>
                                        <option value="<?php echo $doctor['id']; ?>"><?php echo $doctor['nombre']; ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="fecha" class="form-label">Fecha de la Cita</label>
                                <input type="date" class="form-control" id="fecha" name="fecha" min="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="hora" class="form-label">Hora de la Cita</label>
                                <input type="time" class="form-control" id="hora" name="hora" min="08:00" max="18:00" required>
                            </div>
                            <div class="mb-3">
                                <label for="motivo" class="form-label">Motivo de la Consulta</label>
                                <textarea class="form-control" id="motivo" name="motivo" rows="3" required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary">Agendar Cita</button>
                            <a href="mis_citas.php" class="btn btn-secondary">Cancelar</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>